/**
 * Functional control abstractions.
 */
package fj.control;
