/**
 * Abstractions for JDBC connections.
 */
package fj.control.db;
