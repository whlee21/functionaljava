package fj.test.reflect;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Denotes that a property should be excluded from any checking.
 *
 * @version 2.16<br>
 *          <ul>
 *          <li>$LastChangedRevision: 13333 $</li>
 *          <li>$LastChangedDate: 2008-09-14 15:05:11 +1000 (Sun, 14 Sep 2008) $</li>
 *          <li>$LastChangedBy: build $</li>
 *          </ul>
 */
@Documented
@Target({ElementType.FIELD, ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface NoCheck {

}
